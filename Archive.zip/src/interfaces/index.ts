export interface ITodoList {
    id: string
    description: string
    done: boolean
  }